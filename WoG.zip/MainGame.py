from Live import load_game, welcome

name = input('Hi, What is your name ?')
welcome(name)
load_game()
